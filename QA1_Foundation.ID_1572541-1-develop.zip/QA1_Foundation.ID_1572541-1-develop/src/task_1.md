# Назначение разделов

**Certifications** – раздел посвящён сертификациям ISTQB. Здесь можно найти информацию о различных уровнях и типах сертификаций по тестированию ПО, требования к кандидатам, учебные материалы и экзаменационные процессы.
Whether you are new or already established in the testing profession, ISTQB® certification will support you throughout your career. For employers, the ISTQB® Certified Tester scheme will help you to develop and validate the skills in your team, and support recruitment. ISTQB® certifications offer Training Providers multiple opportunities to extend their training course portfolios. Click on each certification for more information.

**Successful Candidate Register (SCR)** — это официальный реестр, который ведется организацией ISTQB (International Software Testing Qualifications Board) для фиксации данных о кандидатах, успешно прошедших сертификационные экзамены по тестированию программного обеспечения.

**Glossary** – глоссарий ISTQB, в котором собраны стандартизированные определения терминов, связанных с тестированием ПО. Это помогает обеспечить единое понимание терминологии среди специалистов по всему миру.

# Определение понятия «отладка»

**Debugging (Отладка)** — это процесс выявления, анализа и устранения причин сбоев в компоненте или системе.