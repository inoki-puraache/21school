function getNOD(first, second) {
    if (second === 0) {
        return first;
    }

    return getNOD(second, first % second);
}