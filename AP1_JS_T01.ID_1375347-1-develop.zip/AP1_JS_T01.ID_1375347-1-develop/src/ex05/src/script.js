const dayStart = "07:30";
const dayEnd = "17:45";

function scheduleMeeting(startTime, durationMinutes) {
    const [startHours, startMinutes] = startTime.split(":").map(Number);
    const meetingStart = startHours * 60 + startMinutes;
    
    const [dayStartHours, dayStartMinutes] = dayStart.split(":").map(Number);
    const workDayStart = dayStartHours * 60 + dayStartMinutes;
    
    const [dayEndHours, dayEndMinutes] = dayEnd.split(":").map(Number);
    const workDayEnd = dayEndHours * 60 + dayEndMinutes;
    
    const meetingEnd = meetingStart + durationMinutes;
    
    return meetingStart >= workDayStart && meetingEnd <= workDayEnd;
}