function alphabetMap(rawString, mapCount) {
    const rules = {
        'a': 'def',
        'b': 'efc',
        'c': 'abe',
        'd': 'cba',
        'e': 'fba',
        'f': 'dcb'
    };
    
    if (mapCount === 0) {
        return rawString;
    }
    
    let transformed = '';
    for (let i = 0; i < rawString.length; i++) {
        transformed += rules[rawString[i]];
    }
    
    return alphabetMap(transformed, mapCount - 1);
}