function getSimpleNumbers(touple) {
    const [start, end] = touple;
    
    const numbers = [];
    for (let i = 2; i <= end; i++) {
        numbers.push(i);
    }
    
    for (let i = 0; i < numbers.length; i++) {
        const current = numbers[i];
        if (current === null) continue;
        
        for (let j = i + 1; j < numbers.length; j++) {
            if (numbers[j] !== null && numbers[j] % current === 0) {
                numbers[j] = null;
            }
        }
    }
    
    const result = [];
    for (let i = 0; i < numbers.length; i++) {
        const num = numbers[i];
        if (num !== null && num >= start) {
            result.push(num);
        }
    }
    
    return result;
}