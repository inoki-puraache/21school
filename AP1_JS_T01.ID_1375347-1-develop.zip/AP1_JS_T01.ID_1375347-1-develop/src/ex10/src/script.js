function getMaxZeroCount(raw) {
    let maxCount = 0;
    let currentCount = 0;
    
    for (let i = 0; i < raw.length; i++) {
        if (raw[i] === '0') {
            currentCount++;
            if (currentCount > maxCount) {
                maxCount = currentCount;
            }
        } else {
            currentCount = 0;
        }
    }
    
    return maxCount;
}