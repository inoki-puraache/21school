function binarySearch(arrayOfNumbers, num) {
    let left = 0;
    let right = arrayOfNumbers.length - 1;
    
    while (left <= right) {
        const middle = Math.floor((left + right) / 2);
        
        if (arrayOfNumbers[middle] === num) {
            return middle;
        }
        
        if (arrayOfNumbers[middle] < num) {
            left = middle + 1;
        } else {
            right = middle - 1;
        }
    }
    
    return -1;
}