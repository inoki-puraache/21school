function sma(arrayOfNumbers, period) {
    const result = [];
    
    for (let i = 0; i < arrayOfNumbers.length; i++) {
        let sum = 0;
        let count = 0;
        
        const startIndex = Math.max(0, i - period + 1);
        
        for (let j = startIndex; j <= i; j++) {
            sum += arrayOfNumbers[j];
            count++;
        }
        
        const average = sum / count;
        result.push(average);
    }
    
    return result;
}