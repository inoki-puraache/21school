function mergeSort(arrayOfNumbers) {
    if (arrayOfNumbers.length <= 1) {
        return arrayOfNumbers;
    }
    
    const middle = Math.floor(arrayOfNumbers.length / 2);
    
    const left = mergeSort(arrayOfNumbers.slice(0, middle));
    const right = mergeSort(arrayOfNumbers.slice(middle));
    
    return merge(left, right);
}

function merge(left, right) {
    const result = [];
    let leftIndex = 0;
    let rightIndex = 0;
    
    while (leftIndex < left.length && rightIndex < right.length) {
        if (left[leftIndex] < right[rightIndex]) {
            result.push(left[leftIndex]);
            leftIndex++;
        } else {
            result.push(right[rightIndex]);
            rightIndex++;
        }
    }
    
    while (leftIndex < left.length) {
        result.push(left[leftIndex]);
        leftIndex++;
    }
    
    while (rightIndex < right.length) {
        result.push(right[rightIndex]);
        rightIndex++;
    }
    
    return result;
}