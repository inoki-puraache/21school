function range(start, end) {
    if (start > end) {
        return [];
    }

    if (start === end) {
        return [start];
    }

    const result = [start]; 

    while (start !== end) { 
        start = start + 1; 
        result.push(start); 
    }

    return result
}
