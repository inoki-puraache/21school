function getNumbersIdBySum(arrayOfNumbers, sum) {
    for (let i = 0; i < arrayOfNumbers.length; i++) {
        for (let j = i + 1; j < arrayOfNumbers.length; j++) {
            if (arrayOfNumbers[i] + arrayOfNumbers[j] === sum) {
                return [i, j];
            }
        }
    }

    return null;
}