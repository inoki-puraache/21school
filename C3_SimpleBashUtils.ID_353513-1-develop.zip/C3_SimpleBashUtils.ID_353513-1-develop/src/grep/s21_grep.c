#include "s21_grep.h"

int main(int argc, char *argv[]) {
  GrepFlags flags = {0};
  char *patterns[MAX_PATTERNS] = {NULL};
  int pattern_count = 0;

  ParseOptions(argc, argv, &flags, patterns, &pattern_count);

  if (pattern_count == 0 && optind < argc) {
    patterns[pattern_count++] = strdup(argv[optind++]);
  } else if (pattern_count == 0) {
    fprintf(stderr, "s21_grep: no pattern specified\n");
    exit(EXIT_FAILURE);
  }

  if (optind >= argc) {
    fprintf(stderr, "s21_grep: no file specified\n");
    exit(EXIT_FAILURE);
  }

  ProcessFiles(argc - optind, &argv[optind], patterns, pattern_count, &flags);
  FreePatterns(patterns, pattern_count);

  return 0;
}

void ParseOptions(int argc, char *argv[], GrepFlags *flags, char *patterns[],
                  int *pattern_count) {
  int opt;

  while ((opt = getopt_long(argc, argv, "e:ivclnhsf:o", NULL, NULL)) != -1) {
    if (opt == -1) break;

    switch (opt) {
      case 'e':
        flags->e = 1;
        if (optarg) {
          if (*pattern_count < MAX_PATTERNS) {
            patterns[(*pattern_count)++] = strdup(optarg);
          }
        } else {
          fprintf(stderr, "s21_grep: option requires an argument -- 'e'\n");
          exit(EXIT_FAILURE);
        }
        break;
      case 'i':
        flags->i = 1;
        break;
      case 'v':
        flags->v = 1;
        break;
      case 'c':
        flags->c = 1;
        break;
      case 'l':
        flags->l = 1;
        break;
      case 'n':
        flags->n = 1;
        break;
      case 'h':
        flags->h = 1;
        break;
      case 's':
        flags->s = 1;
        break;
      case 'f':
        flags->f = 1;
        if (optarg) {
          if (LoadPatternsFromFile(optarg, patterns, pattern_count) == -1 &&
              !flags->s) {
            fprintf(stderr, "s21_grep: %s: No such file or directory\n",
                    optarg);
            exit(EXIT_FAILURE);
          }
        } else {
          fprintf(stderr, "s21_grep: option requires an argument -- 'f'\n");
          exit(EXIT_FAILURE);
        }
        break;
      case 'o':
        flags->o = 1;
        break;
      default:
        fprintf(stderr, "Usage: %s [-eivclnhsf:o] pattern file...\n", argv[0]);
        exit(EXIT_FAILURE);
    }
  }
}

int LoadPatternsFromFile(const char *filename, char **patterns, int *count) {
  FILE *f = fopen(filename, "r");
  if (!f) return -1;
  char *line = NULL;
  size_t len = 0;
  while (getline(&line, &len, f) != -1) {
    line[strcspn(line, "\n")] = '\0';
    if (*count < MAX_PATTERNS) {
      patterns[(*count)++] = strdup(line);
    }
  }
  free(line);
  fclose(f);
  return 0;
}

void PrintOnlyMatches(const char *filename, const char *line,
                      const char *pattern, int ignore_case,
                      int multiple_files) {
  regex_t regex;
  int cflags = REG_EXTENDED | (ignore_case ? REG_ICASE : 0);
  if (regcomp(&regex, pattern, cflags) != 0) return;

  const char *cursor = line;
  regmatch_t match;
  while (regexec(&regex, cursor, 1, &match, 0) == 0) {
    if (multiple_files) {
      printf("%s:", filename);
    }
    printf("%.*s\n", (int)(match.rm_eo - match.rm_so), cursor + match.rm_so);
    cursor += match.rm_eo;
  }
  regfree(&regex);
}

void PrintMatchedLine(const char *filename, const char *line, int line_number,
                      GrepFlags *flags, int multiple_files) {
  if (!flags->l && !flags->c) {
    if (!flags->h && multiple_files) printf("%s:", filename);
    if (flags->n) printf("%d:", line_number);
    printf("%s", line);
    if (line[strlen(line) - 1] != '\n') printf("\n");
  }
}

int MatchLine(const char *line, const char *pattern, int ignore_case) {
  regex_t regex_machine;
  int regex_settings = REG_EXTENDED | (ignore_case ? REG_ICASE : 0);

  if (regcomp(&regex_machine, pattern, regex_settings) != 0) {
    return 0;
  }

  int has_match = regexec(&regex_machine, line, 0, NULL, 0) == 0;
  regfree(&regex_machine);

  return has_match;
}

void ProcessFile(const char *filename, char **patterns, int pattern_count,
                 GrepFlags *flags, int multiple_files) {
  FILE *file_pointer = fopen(filename, "r");
  if (!file_pointer) {
    if (!flags->s) {
      fprintf(stderr, "s21_grep: %s: No such file or directory\n", filename);
    }
    return;
  }

  char *line = NULL;
  size_t len = 0;
  ssize_t read;
  int match_count = 0;
  int line_number = 0;

  while ((read = getline(&line, &len, file_pointer)) != -1) {
    line_number++;
    int matched = 0;

    for (int i = 0; i < pattern_count; i++) {
      if (MatchLine(line, patterns[i], flags->i)) {
        matched = 1;
        break;
      }
    }

    if (flags->v) {
      matched = !matched;
    }

    if (matched) {
      match_count++;
      if (flags->o && !flags->v && !flags->l && !flags->c) {
        for (int i = 0; i < pattern_count; i++) {
          PrintOnlyMatches(filename, line, patterns[i], flags->i,
                           multiple_files);
        }
      } else if (!flags->l && !flags->c) {
        PrintMatchedLine(filename, line, line_number, flags, multiple_files);
      }
    }
  }

  if (flags->l && match_count > 0) {
    printf("%s\n", filename);
  }

  if (flags->c && !flags->l) {
    if (!flags->h && multiple_files) printf("%s:", filename);
    printf("%d\n", match_count);
  }

  free(line);
  fclose(file_pointer);
}

void ProcessFiles(int file_count, char *file_names[], char **patterns,
                  int pattern_count, GrepFlags *flags) {
  int multiple_files = file_count > 1;
  for (int i = 0; i < file_count; i++) {
    ProcessFile(file_names[i], patterns, pattern_count, flags, multiple_files);
  }
}

void FreePatterns(char **patterns, int count) {
  for (int i = 0; i < count; i++) {
    free(patterns[i]);
  }
}
