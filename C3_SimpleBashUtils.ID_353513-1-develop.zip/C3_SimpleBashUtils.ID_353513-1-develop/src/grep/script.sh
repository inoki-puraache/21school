#!/bin/bash

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# Создаем тестовые файлы
create_test_files() {
    echo "Creating test files..."
    
    # test1.txt
    cat <<EOF > test1.txt
hello world
This is a test file
for testing grep functionality
HELLO again
EOF

    # test2.txt
    cat <<EOF > test2.txt
Another file
with different content
hello there
and goodbye
EOF

    # test3.txt (без совпадений)
    cat <<EOF > test3.txt
This file doesn't contain
the search pattern
in any line
EOF

    # patterns.txt (для теста -f)
    cat <<EOF > patterns.txt
hello
world
EOF
}

# Функция для сравнения с grep
test_case() {
    echo "-------------"
    echo "Testing: $1"
    ./s21_grep $1 > s21_output
    grep $1 > grep_output
    if diff s21_output grep_output > /dev/null; then
        echo -e "${GREEN}PASS${NC}"
    else
        echo -e "${RED}FAIL${NC}"
        echo "Differences:"
        diff s21_output grep_output
    fi
    rm s21_output grep_output
    echo
}

# Очистка тестовых файлов
cleanup() {
    echo "Cleaning up test files..."
    rm -f test1.txt test2.txt test3.txt patterns.txt
    echo "Done."
}

# Основная функция
main() {
    # Создаем тестовые файлы
    create_test_files
    
    # Запуск тестов
    test_case "hello test1.txt"
    test_case "-i hello test1.txt test2.txt"
    test_case "-v hello test1.txt"
    test_case "-n hello test2.txt"
    test_case "-c hello test1.txt test2.txt"
    test_case "-l hello test1.txt test3.txt"
    test_case "-o hello test1.txt test2.txt"
    test_case "-e hello -e world test1.txt test2.txt"
    test_case "-f patterns.txt test1.txt test2.txt"
    
    # Очистка
    cleanup
}

# Вызываем основную функцию
main