#ifndef S21_GREP_H
#define S21_GREP_H

#include <getopt.h>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_PATTERNS 100

typedef struct {
  int e;
  int i;
  int v;
  int c;
  int l;
  int n;
  int h;
  int s;
  int f;
  int o;
} GrepFlags;

void ParseOptions(int argc, char *argv[], GrepFlags *flags, char *patterns[],
                  int *pattern_count);
int LoadPatternsFromFile(const char *filename, char **patterns, int *count);
void PrintOnlyMatches(const char *filename, const char *line,
                      const char *pattern, int ignore_case, int multiple_files);
void PrintMatchedLine(const char *filename, const char *line, int line_number,
                      GrepFlags *flags, int multiple_files);
int MatchLine(const char *line, const char *pattern, int ignore_case);
void ProcessFile(const char *filename, char **patterns, int pattern_count,
                 GrepFlags *flags, int multiple_files);
void ProcessFiles(int file_count, char *file_names[], char **patterns,
                  int pattern_count, GrepFlags *flags);
void FreePatterns(char **patterns, int count);

#endif
