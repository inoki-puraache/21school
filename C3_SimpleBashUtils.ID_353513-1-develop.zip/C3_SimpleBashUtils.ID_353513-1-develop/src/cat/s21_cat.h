#ifndef SRC_CAT_S21_CAT_H_
#define SRC_CAT_S21_CAT_H_
#include <stdio.h>  // Для функций работы с файлами: fopen, fclose, fgetc, printf, fprintf
#include <stdlib.h>  // Для макросов: EXIT_FAILURE
#include <unistd.h>  // Для getopt() — обработки аргументов командной строки

#include "s21_cat.h"  // Заголовок с определением структуры флагов и функции обработки

// Структура для хранения флагов cat
typedef struct {
  int b;  // Нумеровать только непустые строки
  int e;  // Показывать символ $ в конце строки
  int n;  // Нумеровать все строки
  int s;  // Сжимать множественные пустые строки
  int t;  // Показывать табуляцию как ^I
  int v;  // Показывать непечатаемые символы
} CatFlags;

// void ProcessFile(const char *file_name, const CatFlags *flags);

#endif  // SRC_CAT_S21_CAT_H_
