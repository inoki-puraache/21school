#include "s21_cat.h"

void ProcessFile(const char *file_name, const CatFlags *flags) {
  FILE *file_pointer = fopen(file_name, "r");
  if (file_pointer == NULL) {
    fprintf(stderr, "s21_cat: %s: No such file or directory\n",
            file_name);  // Ошибка, если файл не найден
    return;
  }
  int current_char;          // Текущий символ из файла
  int previous_char = '\n';  // Предыдущий символ, по умолчанию новая строка
  int line_number = 1;  // Счётчик строк (начинается с 1)
  int consecutive_blank = 0;  // Флаг: обнаружены подряд идущие пустые строки

  while ((current_char = fgetc(file_pointer)) != EOF) {
    if (flags->s && current_char == '\n' && previous_char == '\n') {
      // Если мы еще не обнаружили пустую строку, то пропускаем её
      if (consecutive_blank) {
        continue;  // Пропускаем вторую и последующие пустые строки(пропускает
                   // текущую иттерацию цикла и не выводит строку)
      }
      consecutive_blank = 1;  // Первая пустая строка обнаружена
    } else {
      consecutive_blank = 0;
    }
    if (flags->b && current_char != '\n' && previous_char == '\n') {
      printf("%6d\t", line_number++);
    } else if (flags->n && !flags->b && previous_char == '\n') {
      printf("%6d\t", line_number++);
    }
    if (flags->t && current_char == '\t') {
      printf("^I");
    } else if (flags->e && current_char == '\n') {
      printf("$\n");
    } else if (flags->v && ((current_char < 32 && current_char != '\n' &&
                             current_char != '\t') ||
                            current_char == 127)) {
      printf("^%c", current_char == 127 ? '?' : current_char + 64);
    } else if (!(flags->t && current_char == '\t') &&
               !(flags->e && current_char == '\n')) {
      putchar(current_char);
    }

    previous_char = current_char;  // Сохраняем символ для анализа следующего
  }

  fclose(file_pointer);  // Закрываем файл
}

int main(int argc, char *argv[]) {
  CatFlags flags = {0};
  int current_option;

  while ((current_option = getopt(argc, argv, "benstvET")) != -1) {
    switch (current_option) {
      case 'b':
        flags.b = 1;
        break;
      case 'e':
        flags.e = 1;
        flags.v = 1;
        break;
      case 'n':
        flags.n = 1;
        break;
      case 's':
        flags.s = 1;
        break;
      case 't':
        flags.t = 1;
        flags.v = 1;
        break;
      case 'v':
        flags.v = 1;
        break;
      case 'E':
        flags.e = 1;
        break;
      case 'T':
        flags.t = 1;
        break;
      default:
        fprintf(stderr, "s21_cat: invalid option -- '%c'\n", current_option);
        exit(EXIT_FAILURE);  // Завершение при ошибке
    }
  }

  if (optind == argc) {
    ProcessFile("/dev/stdin", &flags);
  } else {
    for (int i = optind; i < argc; ++i) {
      ProcessFile(argv[i], &flags);
    }
  }
}