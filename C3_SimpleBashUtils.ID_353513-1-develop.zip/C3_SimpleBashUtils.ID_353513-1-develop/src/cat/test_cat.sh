#!/bin/bash

./s21_cat -b test.txt > s21_cat.txt
cat -b test.txt > cat.txt
diff -y s21_cat.txt cat.txt
if diff -q s21_cat.txt cat.txt; then
    echo ""
    echo "flag -b passed✅"
else
    echo ""
    echo "flag -b failed❌"
fi

./s21_cat -e test.txt > s21_cat.txt
cat -e test.txt > cat.txt
diff -y s21_cat.txt cat.txt
if diff -q s21_cat.txt cat.txt; then
    echo ""
    echo "flag -e passed✅"
else
    echo ""
    echo "flag -e failed❌"
fi

./s21_cat -n test.txt > s21_cat.txt
cat -n test.txt > cat.txt
diff -y s21_cat.txt cat.txt
if diff -q s21_cat.txt cat.txt; then
    echo ""
    echo "flag -n passed✅"
else
    echo ""
    echo "flag -n failed❌"
fi

./s21_cat -s test.txt > s21_cat.txt
cat -s test.txt > cat.txt
diff -y s21_cat.txt cat.txt
if diff -q s21_cat.txt cat.txt; then
    echo ""
    echo "flag -s passed✅"
else
    echo ""
    echo "flag -s failed❌"
fi

./s21_cat -t test.txt > s21_cat.txt
cat -t test.txt > cat.txt
diff -y s21_cat.txt cat.txt
if diff -q s21_cat.txt cat.txt; then
    echo ""
    echo "flag -t passed✅"
else
    echo ""
    echo "flag -t failed❌"
fi

./s21_cat -v test.txt > s21_cat.txt
cat -v test.txt > cat.txt
diff -y s21_cat.txt cat.txt
if diff -q s21_cat.txt cat.txt; then
    echo ""
    echo "flag -v passed✅"
else
    echo ""
    echo "flag -v failed❌"
fi

rm -f s21_cat.txt cat.txt
